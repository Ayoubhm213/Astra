fx_version 'cerulean'
game 'gta5'

client_script 'client.lua'
server_script 'server.lua'
shared_script 'config.lua'


