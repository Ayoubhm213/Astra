-- config.lua

Config = {}

Config.AllowedUsers = {
    ["discord:0363"] = "AYOUB", 
    ["discord:"] = "NAME"  
}


Config.WebhookURL = "https://discord.com/api/webhooks/" --LOGS السجلات

Config.CommandName = "go"



