-- server.lua

local function sendToDiscord(name, message, color)
    local connect = {
        {
            ["color"] = color,
            ["title"] = "**" .. name .. "**",
            ["description"] = message,
            ["footer"] = {
                ["text"] = os.date("%Y-%m-%d %H:%M:%S", os.time())
            },
        }
    }
    PerformHttpRequest(Config.WebhookURL, function(err, text, headers) end, 'POST', json.encode({username = "FiveM Bot", embeds = connect}), { ['Content-Type'] = 'application/json' })
end

RegisterServerEvent('go:checkPermission')
AddEventHandler('go:checkPermission', function()
    local src = source
    local discordID = nil
    local playerName = GetPlayerName(src)
    local playerRole = "Unknown"
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if string.match(id, "discord:") then
            discordID = id
            break
        end
    end

    if discordID and Config.AllowedUsers[discordID] then
        playerRole = Config.AllowedUsers[discordID]
        TriggerClientEvent('go:allowed', src)
        sendToDiscord("Command Usage", string.format('تم استخدام الأمر بواسطة %s (%s).', playerName, playerRole), 3066993)
    else
        TriggerClientEvent('chat:addMessage', src, {
            args = { string.format('محاولة وصول غير مصرح بها من %s (%s).', playerName, playerRole) }
        })
        sendToDiscord("Unauthorized Access", string.format('محاولة وصول غير مصرح بها من %s (%s).', playerName, playerRole), 15158332) 
    end
end)


