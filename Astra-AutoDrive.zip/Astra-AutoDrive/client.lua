-- client.lua

local destination = nil
local driving = false
local vehicle = nil
local playerPed = PlayerPedId() 
local blip = nil 

RegisterNetEvent('go:allowed')
AddEventHandler('go:allowed', function()
    playerPed = PlayerPedId()
    vehicle = GetVehiclePedIsIn(playerPed, false)
    if vehicle == 0 then
        TriggerEvent('chat:addMessage', {
            args = { 'أنت لست داخل مركبة.' }
        })
        return
    end


    if not destination then
        TriggerEvent('chat:addMessage', {
            args = { 'لا يوجد وجهة محددة. يرجى تعيين نقطة على الخريطة.' }
        })
        return
    end

    driving = true

    blip = AddBlipForCoord(destination.x, destination.y, destination.z)
    SetBlipRoute(blip, true)

    TaskVehicleDriveToCoordLongrange(playerPed, vehicle, destination.x, destination.y, destination.z, 20.0, 786603, 10.0)

    Citizen.CreateThread(function()
        while driving do
            Citizen.Wait(500)
            local coords = GetEntityCoords(vehicle)
            local distance = Vdist(coords.x, coords.y, coords.z, destination.x, destination.y, destination.z)
                    if distance < 10.0 then
                SetVehicleEngineOn(vehicle, false, true, true) 
                SetVehicleHandbrake(vehicle, true) 
                SetBlipRoute(blip, false)
                RemoveBlip(blip)
                blip = nil
                driving = false
                
                TriggerEvent('chat:addMessage', {
                    args = { 'لقد وصلت إلى الوجهة المحددة.' }
                })
                
                TriggerEvent('chat:addMessage', {
                    args = { 'لقد تم إيقاف القيادة التلقائية. يمكنك الآن التحكم الكامل في السيارة.' }
                })
                
                break
            end
        end
    end)
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsWaypointActive() then
            local waypointBlip = GetFirstBlipInfoId(8)
            if DoesBlipExist(waypointBlip) then
                destination = GetBlipInfoIdCoord(waypointBlip)
            end
        end
    end
end)

RegisterCommand(Config.CommandName, function()
    TriggerServerEvent('go:checkPermission')
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if driving then

            if IsControlJustReleased(0, 73) then

                if vehicle and DoesEntityExist(vehicle) then

                    SetVehicleEngineOn(vehicle, false, true, true)
                    SetVehicleHandbrake(vehicle, false) 
                    driving = false

                    if blip then
                        SetBlipRoute(blip, false)
                        RemoveBlip(blip)
                        blip = nil
                    end

                    TriggerEvent('chat:addMessage', {
                        args = { 'تم إيقاف القيادة التلقائية. يمكنك الآن التحكم الكامل في السيارة.' }
                    })
                end
            end
        end
    end
end)
